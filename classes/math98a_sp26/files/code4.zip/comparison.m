x = input("What is x? ");
y = input("What is y? ");

if x == y
    disp("The numbers are equal.")
else
    disp("The numbers are not equal")
    if x < y 
        disp("because x is less than y.")
    else 
        disp("because x is greater than y.")
    end
end