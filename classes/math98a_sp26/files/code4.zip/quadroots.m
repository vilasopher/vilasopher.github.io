a = input("a: ");
b = input("b: ");
c = input("c: ");
D = b^2 - 4 * a * c;

if D < 0
    disp("Complex roots.")
elseif D == 0
    disp("Repeated real root.")
else 
    disp("Distinct real roots.")
end