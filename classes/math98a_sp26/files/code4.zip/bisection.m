function [p] = bisection(f,a,b,tol)
%BISECTION ...

if f(a) * f(b) > 0
    disp("There is no sign change over [a,b]")
    return
end

while b-a > tol
    p = (a + b) / 2;
    if f(a) * f(p) <= 0 
        b = p;
    else
        a = p;
    end
end

end