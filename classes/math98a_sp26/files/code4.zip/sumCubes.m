function [S] = sumCubes(v)
%SUMCUBES computes the sum of the cubes of elements of a vecotr

S = 0;
for elt = v
    S = S + elt^3;
end

end