%In this exercise, you will exercise your googling skills get MATLAB to do things.

%% Exercise 1a: 
%Given a matrix A, find a command return a matrix B with its columns flipped in the left-right direction.

%Sample:
%A = [1  2   3 4;
%     5  6   7 8;
%     9 10 11 12];
%B = cmd1(A);
%B = [ 4  3  2 1;
%      8  7  6 5;     
%     12 11 10 9];

%Answer: B = fliplr(A);
%(I gave you this one)

%% Exercise 1b:
%Given a matrix A, find a command return a matrix B with its columns flipped in the up-down direction.

%Sample:
%A = [1  2   3 4;
%     5  6   7 8;
%     9 10 11 12];
%B = cmd2(A);
%B = [ 9 10 11 12;
%      5  6  7  8;     
%      1  2  3  4];

%Answer: 

%% Exercise 1c:
%Given any vector v, create a diagonal matrix D whose diagonal entries are the entries of v.

%Sample:
%v = [1, 3, 9, 11];
%D = cmd3(v); 
%D = [1 0 0  0;
%     0 3 0  0;
%     0 0 9  0;
%     0 0 0 11];

%Answer: 

%% Exercise 1d:
%Given a square matrix A, compute the sum s of its diagonal entries.

%Sample:
%A = [1 2 3;
%     4 5 6;
%     7 8 9];
%s = cmd4(A); 
%s = 15 

%Answer: 

%% Exercise 1e:
%Given a column vector v of size 12, reshape it to a 3x4 matrix M so the entries are
%arranged in the following manner.

%Sample:
%v = (1:12)';
%M = cmd5(v);
%M = [1 4 7 10;
%     2 5 8 11;
%     3 6 9 12];

%Answer: 

%%
% In this exercise, you will fill in one-liners with possibly more than one command 
% to do some matrix and vector manipulations.
%% Exercise 2a:
%Given a matrix A with 4 columns, return a vector v with the entries that appear in all 4 columns.

%Sample 1:
% A = [1 2 1 5;
%      2 4 2 4;
%      3 5 5 2;
%      4 7 4 1];
% v = [2; 4]
%Sample 1:
% A = [1 4 7 1;
%      2 5 8 2;
%      3 6 9 3;
%      4 7 1 4];
% v = [];

%Answer: v = intersect(intersect(A(:, 1), A(:, 2)), intersect(A(:, 3), A(:, 4))); 
%(I gave you this one)

%% Exercise 2b:
%Given a vector alpha and a value n, construct the corresponding Vandermonde Matrix V
%https://en.wikipedia.org/wiki/Vandermonde_matrix

%Sample:
%alpha = [1 3 5 10]; n = 4;
%V = [1  1   1    1
%     1  3   9   27
%     1  5  25  125
%     1 10 100 1000]

%Answer: 

%% Exercise 2c:
%Given a vector v, find the indices idxeven of all the even entries

%Sample:
%v = [1 2 6 4 8 3 14 17 pi]
%idxeven = [2 3 4 5 7]

%Answer: 

%% Exercise 2d:
%Given an integer n, compute the matrix H as follows:

%Sample:
%n = 4;
%H = [      1 (1/2)^2 (1/3)^2 (1/4)^2;
%     (1/2)^2 (1/3)^2 (1/4)^2 (1/5)^2;
%     (1/3)^2 (1/4)^2 (1/5)^2 (1/6)^2;
%     (1/4)^2 (1/5)^2 (1/6)^2 (1/7)^2];

%Hint: Hilbert Matrix
%Answer: 

%% Exercise 2e:
%Given two odd integers m and n, return the mxn matrix M that is all zeros
%except for the middle row and middle column, which should all be 1s.

%Sample:
%m = 7; n = 5;
%M = [0 0 1 0 0
%     0 0 1 0 0
%     0 0 1 0 0
%     1 1 1 1 1
%     0 0 1 0 0
%     0 0 1 0 0
%     0 0 1 0 0];

%Answer:













