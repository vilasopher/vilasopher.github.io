x = 7;
y = mysquare(7);
z = myfun(4);

function [y] = mysquare(x)
y = x ^ 2;
end