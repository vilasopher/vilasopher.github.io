function [colsum,rowsum] = sumrowcols(A)
%SUMROWCOLS gets the column and row sums of a matrix
colsum = sum(A, 1);
rowsum = sum(A, 2);
end