function [] = tester()
%UNTITLED16 Summary of this function goes here
%   Detailed explanation goes here
n = -50;
end