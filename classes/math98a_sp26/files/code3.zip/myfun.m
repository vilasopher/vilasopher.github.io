function [n] = myfun(m)
%MYFUN adds 1 to the input

a = m + 1;
b = a^2;
n = b/3;
end