function [sum, diff, prod] = myfun2(a, b)
%MYFUN2 ...

sum = a + b;
diff = a - b;
prod = a * b;
end