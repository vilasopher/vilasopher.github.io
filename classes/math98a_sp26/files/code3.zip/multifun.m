function [z] = multifun(c)
z = mysquare(2) + c;
end

function [y] = mysquare(x)
y = x ^ 2;
end