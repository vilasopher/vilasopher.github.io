function [p] = makeCubic(b, c)
%makeCubic creates the function that evaluates the cubic (x^3 + bx + c)
    function y = myCubic(x)
        y = x .^ 3 + b * x + c;
    end

    p = @myCubic;
end