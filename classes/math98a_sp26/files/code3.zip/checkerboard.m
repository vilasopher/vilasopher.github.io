function [M] = checkerboard(n,m)
%CHECKERBOARD ...
M = zeros(n,m);
M(1:2:end,1:2:end) = 1;
M(2:2:end,2:2:end) = 1;
end