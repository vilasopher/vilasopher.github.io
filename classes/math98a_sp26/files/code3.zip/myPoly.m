function [y] = myPoly(x)
%myPoly ..
y = x .^ 3 - 4 * x + 2;

end