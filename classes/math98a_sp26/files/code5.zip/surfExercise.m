[X,Y] = meshgrid(linspace(0, 2*pi), linspace(0, 2*pi));
Z = 2 * sin(X) .* cos(Y);
surf(X,Y,Z,"EdgeColor","none")
xlabel("x")
ylabel("y")
axis tight;