%% Open up new figures
figure;
figure(10);
figure; % opens up figure with next available number, figure 2
figure(194);

%% Close figures
close; % should close current figure, figure 194
close figure 10; % closes a specified figure
close all; % closes all figures

%% Scatterplots
x = -5:0.1:5;
plot(x, cos(x));
scatter(x, cos(x));
% Go through examples on https://www.mathworks.com/help/matlab/ref/scatter.html

%% Subplots
subplot(2,2,1)
x = linspace(0,10);
y1 = sin(x);
plot(x,y1)
title('Subplot 1: sin(x)')

subplot(2,2,2)
y2 = sin(2*x);
plot(x,y2)
title('Subplot 2: sin(2x)')

subplot(2,2,3)
y3 = sin(4*x);
plot(x,y3)
title('Subplot 3: sin(4x)')

subplot(2,2,4)
y4 = sin(8*x);
plot(x,y4)
title('Subplot 4: sin(8x)')

%% Find and Change Position
gcf % Find position
set(gcf, 'Position', [10, 10, 1000, 500])

%% semilog plots (only log one axis) and loglog plots

x = 1:0.01:10;
y = 2.^x;
figure;
subplot(3, 1, 1);
plot(x, y);
subplot(3, 1, 2);
semilogy(x, y) % also semilogx
subplot(3, 1, 3);
loglog(x, y)

% Note1: Preferable to taking logs of values and plotting them. 
% plot(log(x), log(y)) vs loglog(x, y) since we don't want to actually
% change the values, just the view.
% Note2: Doesn't make sense for negative values. In 128A will be used to
% plot error vs. parameter value (both of which are positive).









