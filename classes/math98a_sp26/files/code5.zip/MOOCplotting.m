%% First Round of Plots
a = (1:10).^2;
figure(1); plot(a)

a = (-10:10).^2;
figure(2); plot(a);

t = -10:10; b = t.^2;
figure(3); plot(t, b);

x1 = 0:0.1:2*pi; y1 = sin(x1);
x2 = pi/2:0.1:3*pi; y2 = cos(x2);
figure(3); plot(x1, y1, x2, y2);

figure(4); plot(x1, y1, 'r', x2, y2, 'k:');
% type 'help plot' in the command window to see all plotting options

%% Second Round of Plots
% figure(1)
% plot(t, b, 'm--o');
% 
% figure(2)
% plot(x1, y1, 'r');
% hold on;
% plot(x2, y2, 'k:');
% hold off;
% plot(x1, y1, 'g*');
% 
% figure(3);
% grid
% title('A Sine Plot and a Cosine Plot')
xlabel('The argument of sine and cosine')
ylabel('The value of the sin or cosine')
legend('sine', 'cosine')
axis([-2 12 -1.5 1.5])


