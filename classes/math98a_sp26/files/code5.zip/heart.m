% coarse and fine plots of a heart
tf = linspace(0,2*pi,100); % see how coarse it is if you use tf = linspace(0,2*pi,17);

fx = @(t) 16*sin(t).^3; 
fy = @(t) 13*cos(t) - 5*cos(2*t) - 2*cos(3*t) - cos(4*t); 

close all; figure;
subplot(1,2,1); 
plot(fx(tf),fy(tf),'r'); 
axis equal; axis tight; 

subplot(1,2,2); 
scatter(fx(tf),fy(tf),'r'); 
axis equal; axis tight;

x0=200;
y0=500;
width=600;
height=300;
set(gcf,'Position', [x0,y0,width,height]); 
