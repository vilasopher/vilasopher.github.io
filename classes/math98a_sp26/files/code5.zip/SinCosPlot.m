% Makes a 3D plot of the function f(x,y) = 2*sin(x)*cos(y)

f = @(x,y) 2*sin(x).*cos(y); % The vectorized notation (.*) is important!

xs = linspace(0,2*pi,60); 
ys = xs; 
[X,Y] = meshgrid(xs,ys); 

close all
surf(X,Y,f(X,Y)) 
colorbar
shading interp
colormap cool