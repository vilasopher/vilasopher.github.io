% Plots cos(x) as well as some approximating Taylor polynoimals. 

P2 = @(x)(1 - x.^2/2); 
P4 = @(x)(1 - x.^2/2 + x.^4/24); 
xs = linspace(-5,5,1000); 

plot(xs,cos(xs),'k'); hold on %default width is 0.5
plot(xs,P2(xs),'r--');
plot(xs,P4(xs),'b-.'); 

xlabel('x','FontSize',15, "Interpreter","latex"); 
ylabel('f(x)','FontSize',15, "Interpreter","latex"); 
title('Taylor approximations to cos(x)','FontSize',15); 

% lgd = legend('cos(x)','P2(x)','P4(x)', 'Location', 'northwest', 'FontSize', 16);

% If you want to do it in LaTeX
lgd = legend('$\cos(x)$','$P_2(x)$','$P_4(x)$', 'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 16);
% Another way to do the LaTeX One
% lgd = legend('$\cos(x)$','$P_2(x)$','$P_4(x)$');
% lgd.Interpreter = 'latex'; 
% lgd.Location = 'northwest'; 
% lgd.FontSize = 16; 

xlim([-pi, pi]); ylim([-1.1, 1.1]);
% axis([])
