% ask the user for their favorite number
fave_number = input("What is your favorite number? ");
disp("I also like " + fave_number)
% z = 1.345
