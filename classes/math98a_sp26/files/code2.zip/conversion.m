tempF = input("What is the temp in F? ");
tempC = (tempF - 32) * (5/9);
disp("The temp in C is " + tempC)